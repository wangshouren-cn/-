import { year } from './b.js';  
console.log(year);