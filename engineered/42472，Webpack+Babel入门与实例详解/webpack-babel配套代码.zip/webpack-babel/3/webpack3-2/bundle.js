/******/ (() => { // webpackBootstrap
var __webpack_exports__ = {};
var add = function add(a, b) {
  return a + b;
};

console.log(add(3, 5));
/******/ })()
;