export var name = 'Rose30';
var age = 18;
// age = 20;
console.log(age);
console.log(222);

if (module.hot) {
  module.hot.accept();
}