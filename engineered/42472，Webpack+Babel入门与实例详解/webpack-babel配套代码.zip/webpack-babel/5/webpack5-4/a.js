import { name } from './b.js';
console.log(name);
console.log(123);