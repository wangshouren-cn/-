let name = 'Tom';
console.log(name);


