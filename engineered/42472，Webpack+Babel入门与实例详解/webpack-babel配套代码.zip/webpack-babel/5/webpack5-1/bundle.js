/******/ (() => { // webpackBootstrap
let name = 'Tom';
console.log(name);



/******/ })()
;