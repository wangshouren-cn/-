/******/ (() => { // webpackBootstrap
var __webpack_exports__ = {};
console.log(true);
console.log("dev");
console.log('Jack');

/******/ })()
;