/******/ (() => { // webpackBootstrap
var __webpack_exports__ = {};
var myAge = 18;
/******/ })()
;