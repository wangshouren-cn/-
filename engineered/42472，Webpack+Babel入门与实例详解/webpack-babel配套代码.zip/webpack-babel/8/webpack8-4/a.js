import num from './nums.hi';
// var num = require('./nums.hi');
// import * as num from './nums.hi';
console.log(num);