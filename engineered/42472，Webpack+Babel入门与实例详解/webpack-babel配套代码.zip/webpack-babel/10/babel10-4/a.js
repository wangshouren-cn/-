
var promise = Promise.resolve('ok');
console.log(promise);