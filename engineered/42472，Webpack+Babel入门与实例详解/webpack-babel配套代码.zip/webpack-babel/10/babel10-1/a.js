// import './polyfill.js';

var promise = Promise.resolve('ok');
console.log(promise);