// 这个例子不是用来运行的。a2.js是手动引入包后的代码，不是命令生成的。
class Person {
  sayname() {
    return 'name'
  }
}

var john = new Person()
console.log(john)