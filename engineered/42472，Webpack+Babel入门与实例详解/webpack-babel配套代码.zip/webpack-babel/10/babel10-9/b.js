"use strict";

require("core-js/modules/es7.array.flat-map.js");

require("core-js/modules/es6.array.iterator.js");

require("core-js/modules/es6.array.sort.js");

require("core-js/modules/es7.object.define-getter.js");

require("core-js/modules/es7.object.define-setter.js");

require("core-js/modules/es7.object.lookup-getter.js");

require("core-js/modules/es7.object.lookup-setter.js");

require("core-js/modules/es7.promise.finally.js");

require("core-js/modules/es7.symbol.async-iterator.js");

require("core-js/modules/es7.string.trim-left.js");

require("core-js/modules/es7.string.trim-right.js");

require("core-js/modules/web.timers.js");

require("core-js/modules/web.immediate.js");

require("core-js/modules/web.dom.iterable.js");

var promise = Promise.resolve('ok');
console.log(promise);
