"use strict";

var fn = num => num + 2;
