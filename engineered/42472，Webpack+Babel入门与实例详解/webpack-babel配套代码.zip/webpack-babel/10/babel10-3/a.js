// import "core-js/stable";
// import "regenerator-runtime/runtime";

var promise = Promise.resolve('ok');
console.log(promise);