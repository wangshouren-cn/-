module.exports = {
  presets: ["@babel/env"],
  plugins: []
}