class Person {
  sayname() {
    return 'name'
  }
}

var john = new Person()
console.log(john)