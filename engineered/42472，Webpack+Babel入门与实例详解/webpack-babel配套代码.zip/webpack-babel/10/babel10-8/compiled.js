"use strict";

var fn = function fn(num) {
  return num + 2;
};
