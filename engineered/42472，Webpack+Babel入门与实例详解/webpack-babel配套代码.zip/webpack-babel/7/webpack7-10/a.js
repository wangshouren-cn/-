// import('./b.js');
import _ from 'lodash'
import { name } from './b.js';
var num = _.random(0, 5);
console.log(name);
console.log(num);


