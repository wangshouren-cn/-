import * as moduleA from './a.js';
console.log(moduleA.person.name);