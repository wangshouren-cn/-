import * as person from './b.js';
export {person};