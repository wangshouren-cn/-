var name = 'Jack';
var year = 2022;
export {name, year};