import { name } from './b.js';
import './c.css';
console.log(name);