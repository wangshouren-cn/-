import('./b.js');
import _ from 'lodash';
var num = _.random(0, 5);
console.log(num);


