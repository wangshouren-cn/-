export var name = 'Jack';
import _ from 'lodash'
var numB = _.random(10, 15);
console.log(numB);
