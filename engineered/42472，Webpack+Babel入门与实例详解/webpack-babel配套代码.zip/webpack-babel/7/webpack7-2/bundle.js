/******/ (() => { // webpackBootstrap
let year = 2022;
console.log(year);
/******/ })()
;