import { year } from './d.js';
console.log(year);
