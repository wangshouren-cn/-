import { year } from './d.js';
export var name = 'Jack';
console.log(numB);
console.log(year);
