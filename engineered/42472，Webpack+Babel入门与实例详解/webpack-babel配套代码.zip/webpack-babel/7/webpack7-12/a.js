import { name } from './b.js';
import { year } from './d.js';
console.log(name);
console.log(year);


