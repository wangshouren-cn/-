module.exports = {
  // presets: [],
  plugins: [['./plugins/letToVar.js', {
  	ES5: false
  }]]
}