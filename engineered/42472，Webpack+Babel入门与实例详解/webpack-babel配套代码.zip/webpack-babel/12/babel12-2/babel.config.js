module.exports = {
  // presets: [],
  plugins: ['./plugins/letToVar.js']
}