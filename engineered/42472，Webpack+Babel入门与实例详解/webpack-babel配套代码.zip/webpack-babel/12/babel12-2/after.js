var animal = 'sunry';
