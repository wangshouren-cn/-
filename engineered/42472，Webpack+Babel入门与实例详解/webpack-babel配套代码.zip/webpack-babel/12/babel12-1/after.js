let animal = 'sunry';
