module.exports = {
  // presets: [],
  plugins: ['./plugins/animalToDog.js']
}