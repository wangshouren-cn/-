var year = 2022;
console.log(year);