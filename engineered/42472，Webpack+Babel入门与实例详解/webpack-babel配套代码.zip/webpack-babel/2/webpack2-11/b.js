let age = 18;
console.log(age);