let name = 'Jack';
console.log(name);